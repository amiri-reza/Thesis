from django.contrib import admin
from cutting_performance.models import NaturalStone, Abrasive, CuttingData

admin.site.register(NaturalStone)
admin.site.register(Abrasive)
admin.site.register(CuttingData)
